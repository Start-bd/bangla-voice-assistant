# Deployment Guide

Complete guide to deploy the Bangla Voice Assistant to production.

## 📋 Pre-Deployment Checklist

- [ ] Backend code tested locally
- [ ] API keys obtained (Soniox + OpenAI)
- [ ] GitHub repository created
- [ ] Android app configured with production URL

---

## 🚀 Backend Deployment

### Option 1: Render (Recommended - Free)

1. **Push to GitHub**
   ```bash
   cd backend
   git init
   git add .
   git commit -m "Initial backend"
   git remote add origin https://github.com/YOUR_USERNAME/bangla-voice-assistant.git
   git push -u origin main
   ```

2. **Create Render Account**
   - Go to [render.com](https://render.com)
   - Sign up with GitHub

3. **Create Web Service**
   - Click "New +" → "Web Service"
   - Connect your GitHub repo
   - Configure:
     - **Name**: `bangla-voice-assistant-api`
     - **Environment**: `Node`
     - **Build Command**: `npm install`
     - **Start Command**: `npm start`
   - Click "Create Web Service"

4. **Add Environment Variables**
   - Go to Environment tab
   - Add:
     - `SONIOX_API_KEY` = your_soniox_key
     - `OPENAI_API_KEY` = your_openai_key
   - Save changes

5. **Get Your URL**
   - Wait for deployment (2-3 minutes)
   - Your URL: `https://bangla-voice-assistant-api.onrender.com`

### Option 2: Railway

1. Go to [railway.app](https://railway.app)
2. New Project → Deploy from GitHub repo
3. Add environment variables
4. Deploy!

### Option 3: Fly.io

```bash
# Install flyctl
curl -L https://fly.io/install.sh | sh

# Login
fly auth login

# Launch
fly launch

# Set secrets
fly secrets set SONIOX_API_KEY=your_key
fly secrets set OPENAI_API_KEY=your_key

# Deploy
fly deploy
```

---

## 📱 Android App Deployment

### Step 1: Update Backend URL

Edit `android-app/app/src/main/java/com/banglavoiceassistant/data/RetrofitClient.kt`:

```kotlin
// Change from:
private const val BASE_URL = "http://10.0.2.2:3000/"

// To your production URL:
private const val BASE_URL = "https://bangla-voice-assistant-api.onrender.com/"
```

### Step 2: Build Release APK

1. **Generate Signing Key** (one-time)
   ```bash
   cd android-app
   keytool -genkey -v -keystore voice-assistant.keystore -alias voiceassistant -keyalg RSA -keysize 2048 -validity 10000
   ```

2. **Build in Android Studio**
   - Build → Generate Signed Bundle/APK
   - Select APK
   - Choose your keystore
   - Build variant: release
   - Finish

3. **Find APK**
   - Location: `app/release/app-release.apk`

### Step 3: Install on Phone

1. Transfer APK to phone (USB, email, or cloud)
2. On phone: Settings → Security → Allow unknown sources
3. Install APK
4. Grant all permissions when prompted

---

## 🧪 Testing Production

### Test Backend
```bash
curl https://your-backend.onrender.com/health
```

### Test Full Flow
1. Open app on phone
2. Tap "Start Voice Assistant"
3. Tap bubble → Tap mic
4. Say: "আমি রিয়াজকে কল করতে চাই"
5. Should see translation and dialer opens

---

## 🔧 Troubleshooting Production

### Backend Issues

| Issue | Solution |
|-------|----------|
| 500 errors | Check logs on Render dashboard |
| STT fails | Verify SONIOX_API_KEY |
| LLM fails | Verify OPENAI_API_KEY |
| CORS errors | Backend already has CORS enabled |

### App Issues

| Issue | Solution |
|-------|----------|
| Can't connect | Check BASE_URL, ensure HTTPS |
| Bubble not showing | Grant overlay permission |
| Recording fails | Grant microphone permission |
| Actions not working | Grant contacts/phone permissions |

---

## 💰 Cost Estimation

### Free Tier (Sufficient for personal use)

| Service | Cost | Limits |
|---------|------|--------|
| Render | Free | Sleeps after 15min inactivity |
| Soniox | $0.006/min | Pay-as-you-go |
| OpenAI GPT-3.5 | ~$0.002/1K tokens | Very cheap |

### Estimated Monthly Cost (Personal Use)
- 100 commands/month
- ~5 min audio total
- **Total: ~$1-2/month**

---

## 🔄 Updating Production

### Update Backend
```bash
git add .
git commit -m "Update"
git push origin main
# Auto-deploys on Render
```

### Update Android App
1. Increment `versionCode` in `build.gradle.kts`
2. Build new APK
3. Reinstall on phone

---

## 📊 Monitoring

### Render Dashboard
- View logs: Dashboard → Logs
- Metrics: CPU, memory, requests
- Set up alerts for errors

### Add Logging (Optional)
Add to `server.js`:
```javascript
// Log all requests
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});
```

---

## 🎯 Next Steps

After deployment:
1. Test all actions (call, camera, YouTube, Lovable)
2. Share with friends!
3. Collect feedback
4. Add more features

**Happy deploying! 🚀**