# Bangla Voice Assistant - Backend

Node.js backend for the Bangla Voice Assistant Android app. Handles speech-to-text (Bangla), translation to English, and intent classification.

## Features

- 🎤 **Speech-to-Text**: Converts Bangla audio to text using Soniox API
- 🌐 **Translation**: Translates Bangla to natural English using OpenAI GPT
- 🎯 **Intent Classification**: Identifies user intent (call, search, build, etc.)
- 📱 **REST API**: Simple endpoints for Android app integration

## API Endpoints

### Health Check
```
GET /health
```

### Voice Command (Main)
```
POST /voice/command
Content-Type: multipart/form-data

Fields:
- audio: Audio file (m4a, wav, etc.)
- mode: "agent" | "translate_only"
- language: "bn"
```

Or with base64:
```
POST /voice/command
Content-Type: application/json

{
  "audioBase64": "<base64-encoded-audio>",
  "metadata": {
    "language": "bn",
    "mode": "agent"
  }
}
```

### Test Endpoint (Dummy Data)
```
POST /voice/command/test
{
  "testIntent": "call_contact" | "open_youtube" | "lovable_build" | "open_camera"
}
```

## Response Format

```json
{
  "transcriptBn": "আমি রিয়াজকে কল করতে চাই",
  "englishText": "I want to call Riaz.",
  "intent": "call_contact",
  "contactName": "Riaz",
  "searchQuery": null,
  "promptForBuilder": null
}
```

## Setup

1. Install dependencies:
```bash
npm install
```

2. Create `.env` file:
```bash
cp .env.example .env
# Edit .env with your API keys
```

3. Run locally:
```bash
npm run dev
```

4. Deploy to production (Render/Railway/Fly.io):
```bash
# Push to GitHub, then connect to your preferred platform
```

## Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `SONIOX_API_KEY` | Soniox API for Bengali STT | Yes |
| `OPENAI_API_KEY` | OpenAI API for LLM | Yes |
| `PORT` | Server port | No (default: 3000) |

## Deployment

### Render (Recommended)
1. Push code to GitHub
2. Create new Web Service on Render
3. Connect GitHub repo
4. Set environment variables
5. Build command: `npm install`
6. Start command: `npm start`

### Railway
1. Push code to GitHub
2. Create new project on Railway
3. Deploy from GitHub
4. Add environment variables

## Testing

```bash
# Health check
curl http://localhost:3000/health

# Test with dummy data
curl -X POST http://localhost:3000/voice/command/test \
  -H "Content-Type: application/json" \
  -d '{"testIntent": "call_contact"}'
```
